<?php
interface InterfaceWithStaticMethod
{
    public static function staticMethod();
}
