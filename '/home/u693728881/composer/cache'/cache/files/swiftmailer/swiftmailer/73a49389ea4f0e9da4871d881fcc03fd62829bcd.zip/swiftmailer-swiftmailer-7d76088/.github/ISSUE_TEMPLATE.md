<!-- Please fill in this template according to your issue. -->

| Q                   | A
| ------------------- | -----
| Bug report?         | yes/no
| Feature request?    | yes/no
| RFC?                | yes/no
| How used?           | Standalone/Symfony/3party
| Swiftmailer version | x.y.z
| PHP version         | x.y.z

### Observed behaviour
<!-- What does the code do? -->

### Expected behaviour
<!-- What should the code do? -->

### Example
<!-- Example to reproduce the issue. -->
